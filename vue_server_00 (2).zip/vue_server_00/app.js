// express基础模块
const express=require('express');
// 解析查询字符串
const bodyParser=require('body-parser');
// 解决跨域的模块
const cors=require('cors');
const session=require('express-session');
// 引入商品列表路由
const list=require('./routes/list_router');
const Login=require('./routes/login');
const Register=require('./routes/register');
var app=express();
var server=app.listen(3001);
app.use(session({
  secret:'128位字符串',
  resave:false,  //每次请求是否更新数据
  saveUninitialized:true   //保存初始化数据
}))
// 托管静态资源
app.use(express.static('./public'));
// 允许跨域访问的url
app.use(cors({
  origin:["http://127.0.0.1:8100","http://localhost:8100"],
  credentials:true
}))

// 查询字符串解析
app.use(bodyParser.urlencoded({extended:false}));
// 商品列表路由
app.use('/list',list);
app.use('/Login',Login);
app.use('/Register',Register);














// //app.js
// //1:复制服务器端模块
// //2:引入第三方模块
// //  mysql/express/
// const mysql = require("mysql");
// const express = require("express");
// //3:创建连接池
// const pool = mysql.createPool({
//   host:"127.0.0.1",
//   user:"root",
//   password:"",
//   database:"xz"
// });
// //4:创建express对象
// var server = express(); 
// //5:绑定监听端口 3000
// server.listen(3000);
// //6:处理用户登录请求
//   //login GET
// server.get("/login",(req,res)=>{
//   //6.1:获取参数
//   var name = req.query.name;
//   var pwd = req.query.pwd;
//   //6.2:创sql
//   var sql = "SELECT id FROM xz_login";
//   sql+=" WHERE name = ? AND pwd=md5(?)";
//   //6.3:执行sql
//   pool.query(sql,[name,pwd],(err,result)=>{
//      if(err)throw err;
//      //6.4:获取返回结果
//      //6.5:判断结果返回 登录成功或者失败
//      if(result.length==0){
//        res.send({code:-1,msg:"用户名或密码有误"});
//      }else{
//        res.send({code:1,msg:"登录成功"})
//      }
//   });
// });     






