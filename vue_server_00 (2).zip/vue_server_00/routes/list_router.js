const express=require('express');
const pool=require('../pool.js');
var router=express.Router();

router.get('/',(req,res)=>{
  // 获取模糊查询需要关键字
  var n=req.query.pname;
  // 获取页码，和页大小
  // console.log(n)
  if(!n){
  var pno=req.query.pno;
  // console.log(pno)
  // 查询语句（公司里面不要用*）
  var sql='select * from m_list limit ?,?';
  // 如果没有页码和页大小
  if(!pno){
    pno=1;
  }
  var pageSize=10;
  // 声明一个要返回的对象
  var obj={code:200};
  // 异步请求有2个请求，判断请求进度，等于100时可以返回res.send
  var progress=0;
  // 起始值
  var offset=parseInt((pno-1)*pageSize);
pool.query(sql,[offset,pageSize],(err,result)=>{
  if(err) throw err;
  progress+=50;
  obj.data=result;
  // console.log(obj)
  if(progress==100){
    res.send(obj)
  }
})
// 判断总页数，如果一查询出全部的数据，不在发送请求
  var sql1='select count(pid) AS p from m_list';
  pool.query(sql1,(err,result)=>{
    // 抛出错误
    if(err) throw err;
    // 进程变量，计算进程
    progress+=50;
    // 获得数据库总页数
    var ps=Math.ceil(result[0].p/pageSize);
    // 结果加入要返回的对象中
    obj.pageSize=ps;
    // 如果两个请求都完成，马上返回对象
    if(progress==100){
      res.send(obj)
    }
  })
}else if(n){
  var sql2='';
  if(n=="新品推荐"){
    sql2='select * from m_list order by time limit 0,6';
  }else if(n=="所有商品"){
    sql2='select * from m_list';
  }else{
  sql2=`select * from m_list where title like "%${n}%"`;
  }
  pool.query(sql2,[n],(err,result)=>{
    if(err) throw err;
    res.send(result)
  })
}
})

// 按照月销售数量降序排列
  router.get("/sales",(req,res)=>{
    var n=req.query.pname;
    var sql=''
    if(!n){
      sql='select * from m_list order by salesVolume desc';
    }else if(n){
      sql=`select * from m_list where title like "%${n}%" order by salesVolume desc`;
    }
    pool.query(sql,(err,result)=>{
      console.log(sql)
      if(err) throw err;
      console.log(result)
      res.send(result)
    })
  })

  // 按照上架时间获得商品列表
  router.get('/new',(req,res)=>{
    var n=req.query.pname;
    var sql=""
    if(!n){
     sql='select * from m_list order by time desc';
    }else if(n){
      sql=`select * from m_list where title like "%${n}%" order by time desc`;
    }
    pool.query(sql,(err,result)=>{
      if(err) throw err;
      res.send(result)
    })
  })

  // 按照价格升或则降序序获得商品列表
  router.get('/price',(req,res)=>{
    var order=req.query.num;
    var n=req.query.pname;
    var sql="";
    if(!n){
      if(order%2!=0){
        sql='select * from m_list order by price';
      }else{
        sql='select * from m_list order by price desc';
      }
    }else if(n){
      if(order%2!=0){
        sql=`select * from m_list where title like "%${n}%" order by price`;
      }else{
        sql=`select * from m_list where title like "%${n}%" order by price desc`;
      }
    }
    
    pool.query(sql,(err,result)=>{
      if(err) throw err;
      res.send(result);
    })
  })

// 导出路由
module.exports=router;

