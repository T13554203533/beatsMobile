// 基础模块express
const express=require('express');
// 数据库连接
const pool=require('../pool.js');
// 
var router=express.Router();

router.get('/',(req,res)=>{
  var n=req.query.name;
  var p=req.query.pwd;
  var t=req.query.phone;
  console.log(n,p,t)
  var sql='select * from m_user where uname=? or phone=?';
  pool.query(sql,[n,t],(err,result)=>{
    if(err) throw err;
    if(result.length>0){
      res.send({code:-3,message:'用户名或手机号已被注册'})
    }else{
      var sql='insert into m_user values (null,?,md5(?),?)';
      pool.query(sql,[n,p,t],(err,result)=>{
        if(err) throw err;
          res.send({code:201,message:'注册成功'})
        })
    }
  })
})

// 导出路由模块
module.exports=router;