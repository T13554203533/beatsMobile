const express=require('express');
const pool=require('../pool.js');
var router=express.Router();


router.get('/',(req,res)=>{
    var n=req.query.name;
    var p=req.query.pwd;
console.log(n,p)
    var sql='select * from m_user where uname=? and pwd=md5(?)';
    pool.query(sql,[n,p],(err,result)=>{
        if(err) throw err;
        console.log(result)
        if(result.length>0){
            res.send({code:200,message:'登录成功'})
        }else{
            res.send({code:-1,message:'登录失败,用户名或密码有误'})
        }
    })
})
module.exports=router;