<template>
  <div>
     <div class="index_infor" style="border-top:1px solid #fff;">
    <img src="../../img/index_img/39.jpg" alt="">
    <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_infor">
    <img src="../../img/index_img/41.jpg" alt="">
     <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_infor">
    <img src="../../img/index_img/42.jpg" alt="">
     <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_kind">
    <img src="../../img/index_img/43.jpg" alt="">
    <img src="../../img/index_img/44.jpg" alt="">
    <img src="../../img/index_img/45.jpg" alt="">
  </div>
  <div class="index_brand">
    <img src="../../img/index_img/46.jpg" alt="">
  </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      
    }
  }
}
</script>
<style>
  /* 头部样式 */
  .In_header{
    width:100%;
    background-color:#000;
    height:45px;
    position:relative;
    margin-bottom:5px;
  }
  .In_header div:first-child{
    width:10%;
    height:45px;
    text-align:center;
    position:absolute;
    top:0;
    left:0;
  }
  .In_header div:first-child a span{
    line-height:45px;
    font-size:32px;
    height:45px;
    color:#fff;
    width:100%;
    display:block;
  }
  .In_header div:last-child{
    color:#fff;
    width:100%;
    text-align: center;
    font-size:16px;
    height:45px;
    line-height:45px;
    font-weight:bold;
  }
  /* 内容样式 */
  .index_infor{
    width:100%;
    box-sizing:border-box;
    position:relative;
  }
  #interact .index_infor img:first-child{
    width:100%;
  }
  #interact .index_infor img:last-child{
    width:30%;
    position:absolute;
    bottom:13%;
    left:35%;
  }
  .index_kind{
    display: flex;
    justify-content: space-around;
    width:100%;
  }
  .index_kind img{
    width:32%;
    height:100%;
  }
  .index_brand{
    width:100%;
    box-sizing: border-box;
    margin-top:15px;
  }
  .index_brand img{width:100%;}

</style>
