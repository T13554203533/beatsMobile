<template>
    <div class='index_bottom'>
    <div></div>
    <ul>
      <li @click='jumpLogin'>登录</li>
      <li>|</li>
      <li><router-link to="/Home" style="color:#929292">
        店铺首页
        </router-link>
        </li>
      <li>|</li>
      <li>下载客户端</li>
    </ul>
  </div>
</template>
<script>
export default {
  data(){
    return{
      
    }
  },
  methods:{
  // 跳转到登录页
    jumpLogin(){
      this.$router.push('/Login')
    }
  },
  // // 跳转到首页
  // jumpHome(){
  //   this.$router.push('/Home')
  // }
}
</script>
<style scoped>
  .index_bottom{
    width:100%;
    height:100px;
    background-color:#fff;
  }
   .index_bottom div{
    border-bottom:2px solid #000;
    width:100%;
  }
   .index_bottom ul{
    list-style:none;
    display:flex;
    justify-content:center;
    text-align:center;
    white-space:nowrap;
    text-overflow:ellipsis;
    padding:0;
    margin-top:15px;
  }
  .index_bottom ul li {
    width:15%;
    color:#a9a9a9;
    font-size:14px;
  }
</style>
