<template>
  <div class="app-list">
    <mt-header title="学子商城">
    </mt-header> 
    <h1>列表组件</h1>
    <mt-button>登录按钮</mt-button>
  </div>
</template>
<script>
  export default {
    data(){
      return {}
    }
  }
</script>

