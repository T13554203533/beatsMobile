<template>
  <div id="register">
      <div class="r_header">
        <div class="back">
          <a @click="jumpTo"><span class="mui-icon mui-icon-back"></span></a>
         </div>
        新用户注册
      </div>
      <div>
        <form class="mui-input-group">
    <div class="mui-input-row">
        <label>账户</label>
    <input v-model='name' type="text" class="mui-input-clear" placeholder="请输入6-8位用户名">
    </div>
    <div class="mui-input-row">
        <label>密码</label>
        <input v-model='pwd' type="password" class="mui-input-password" placeholder="请输入6-8位密码">
    </div>
    <div class="mui-input-row">
        <label>手机</label>
        <input v-model='phone' type="text" class="mui-input-password" placeholder="请输入手机号码">
    </div>
    <!-- <div class="mui-input-row">
        <label>邮箱</label>
        <input type="password" class="mui-input-password" placeholder="请输入密码">
    </div> -->
    </form>
      </div>
      <button class="ulogin" @click='btnRegister'>注册</button>
  </div>
</template>
<script>
import {Toast} from "mint-ui"
export default {
  data(){
    return{
        name:'',
        pwd:'',
        phone:''
    }
  },
  methods:{
    jumpTo(){
        this.$router.push('/Login')
      },
      // 登录功能按钮
      btnRegister(){
        var n=this.name;
        var p=this.pwd;
        var t=this.phone;
        var nreg=/^\w{6,8}$/;
        var preg=/^\w{6,8}$/;
        var treg=/^1[3-8]\d{9}$/;
        if(!nreg.test(n)){
          Toast('用户名格式有误')
          return;
        }
        if(!preg.test(p)){
          Toast('密码格式有误')
          return;
        }
        if(!treg.test(t)){
          Toast('请输入正确的手机号')
          return;
        }
        var url='http://127.0.0.1:3001/Register?name='+n+"&pwd="+p+"&phone="+t;
        this.axios.get(url).then(result=>{
          console.log(result.data)
          Toast(result.data.message)
          if(result.data.code==201){
            setInterval(
              ()=>{
                var i=0;
                i++;
                if(i>=1){
                this.$router.push('/Login')
                }
              }
            ,3000)  
          }
        })
      }
  }
}
</script>
<style>
#register{
  position:relative;
}
.r_header{
  height:45px;
  width:100%;
  background-color:#fff;
  font-size:18px;
  line-height:45px;
  text-align:center;
  margin-bottom:10px;
}
.back{
  position:absolute;
  left:1%;
  top:0;
}
#register .back a span{
  color:#000;
  font-size:28px;
}
#register .mui-input-row{
  height:50px;
}
#register .mui-input-row label{
  font-size:16px;
  color:#929292;
  width:25%;
  padding:0;
  height:50px;
  line-height:50px;
  display:inline-block;
  text-align:center;
}
#register .mui-input-row input {
  width:75%;
  font-size:16px;
  color:000;
  background-color: transparent;
  height:50px;
  line-height:50px;
  display:inline-block;
}
/* 设置input框placeholder中字体的颜色 */
#register .mui-input-row input::-webkit-input-placeholder {
color: #ccc;font-size:16px;
}
.ulogin{
  margin-left:2%;
  width:96%;
  margin-top:25px;
  background-color:#dd2727;
  color:#fff;
  height:45px;
  font-size:16px;
}
</style>
