<!--src/components/tabbar/Login.vue-->
<template>
  <div id="login">
     <div class="l_header">
       <div class="back">
       <a @click="jumpTo"><span class="mui-icon mui-icon-back"></span></a>
     </div>
       用户登录
     </div>
     <form class="mui-input-group">
    <div class="mui-input-row">
        <label>账户</label>
    <input v-model='name' type="text" class="mui-input-clear" placeholder="请输入用户名" name="uname">
    </div>
    <div class="mui-input-row">
        <label>密码</label>
        <input v-model='pwd' type="password" class="mui-input-password" placeholder="请输入密码" name="pwd">
    </div>
</form>
    <button class="ulogin" @click='btnLogin'>登录</button>
    <div class="register">
      <router-link to="/Register">免费注册</router-link>
    </div>
  </div>
</template>
<script>
// 在export之前引入组件
  import {Toast} from "mint-ui"
  export default {
    data(){
      return {
        name:'',
        pwd:''
      }
    },
    methods:{
      // 返回跳转到首页
      jumpTo(){
        this.$router.push('/Home')
      },
      btnLogin(){
        //功能:获取用户输入用户名和密码
        //验证如果通过发送ajax请求给服务器
        //程序并且获得返回结果
       //1:获取用户输入用户名和密码
       var n=this.name;
       var p=this.pwd;
       //2:创建正则表达式
       var ureg=/^\w{6,8}$/;
       var preg=/^\w{6,8}$/;
       //   用户名 字母数字下划线 3~8
       //   密码   数字          3~8
       if(!ureg.test(n)){
         Toast("您输入的账户有误");
         return;
       }
       //3:验证用户名如果失败 提示错误信息
       //4:验证密码如果失败   提示错误信息
       if(!preg.test(p)){
         Toast('密码格式有误');
         return;
       }
       //5:发送ajax请求
       var url='http://127.0.0.1:3001/login';  
       url+='?name='+n+"&pwd="+p;
       this.axios.get(url).then(result=>{
           Toast(result.data.message)  
       })
       //   http://127.0.0.1:3000/login
       //6:获取返回结果
       //7:提示 登录成功或者用户名或密码有误    
      }
    }
  }
</script>
<style>
#login{
  position:relative;
}
.l_header{
  height:45px;
  line-height:45px;
  font-size:18px;
  text-align:center;
  background-color:#fff;
  margin-bottom:15px;
}
#login .mui-input-row{
  height:50px;
}
#login .mui-input-row label{
  font-size:16px;
  color:#929292;
  width:25%;
  padding:0;
  height:50px;
  line-height:50px;
  display:inline-block;
  text-align:center;
}
#login .mui-input-row input {
  width:75%;
  font-size:16px;
  color:000;
  background-color: transparent;
  height:50px;
  line-height:50px;
  display:inline-block;
}
/* 设置input框placeholder中字体的颜色 */
#login .mui-input-row input::-webkit-input-placeholder {
color: #ccc;font-size:16px;
}
.ulogin{
  margin-left:2%;
  width:96%;
  margin-top:25px;
  background-color:#dd2727;
  color:#fff;
  height:45px;
  font-size:16px;
}
.register{
  float:right;
  margin-right:2%;
  margin-top:3%;
  font-size:14px;
}
.register a{color:#dd2727;}
.back{
  position:absolute;
  left:1%;
  top:0;
}
#login .back a span{
  color:#000;
  font-size:28px;
}
</style>

