<template>
    <div id="interact">
       <div class="In_header">
        <div @click="jumpTo">
          <a><span class="mui-icon mui-icon-back"></span></a>
        </div>
        <div>beats官方旗舰店-互动吧</div>
      </div>
     <!-- <div class="index_infor" style="border-top:1px solid #fff;">
    <img src="../../img/index_img/39.jpg" alt="">
    <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_infor">
    <img src="../../img/index_img/41.jpg" alt="">
     <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_infor">
    <img src="../../img/index_img/42.jpg" alt="">
     <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_kind">
    <img src="../../img/index_img/43.jpg" alt="">
    <img src="../../img/index_img/44.jpg" alt="">
    <img src="../../img/index_img/45.jpg" alt="">
  </div>
  <div class="index_brand">
    <img src="../../img/index_img/46.jpg" alt="">
  </div> -->
  <mycontent></mycontent>
  <myfooter></myfooter>
</div> 
</template>
<script>
// 引入尾部组件
import myfooter from '../common/footer.vue'
import mycontent from '../common/content.vue'
export default {
  data(){
    return{
      backRouter:''
    }
  },
  created(){
    this.backRouter=this.$route.query.name
  },
  methods:{
    jumpTo(){
      this.$router.push(this.backRouter)
    }
  },
  // 并且配置为子组件
  components:{
    myfooter,mycontent
  }
}
</script>
<style>
   .In_header{
    width:100%;
    background-color:#000;
    height:45px;
    position:relative;
    margin-bottom:5px;
  }
  .In_header div:first-child{
    width:10%;
    height:45px;
    text-align:center;
    position:absolute;
    top:0;
    left:0;
  }
  .In_header div:first-child a span{
    line-height:45px;
    font-size:32px;
    height:45px;
    color:#fff;
    width:100%;
    display:block;
  }
  .In_header div:last-child{
    color:#fff;
    width:100%;
    text-align: center;
    font-size:16px;
    height:45px;
    line-height:45px;
    font-weight:bold;
  }
</style>
