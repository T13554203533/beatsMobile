<template>
  <div id="chat">
    <div class="c_header">
      <div @click='jumpBack'>
        <a><span class="mui-icon mui-icon-back"></span></a>
      </div>
      <div>
        beats官方旗舰店
      </div>
      <div @click="jumpCart">
        <a><span class="mui-icon-extra mui-icon-extra-cart"></span></a>
      </div>
    </div>
    <div class="chat_content">
      亲，该功能还未上线
    </div>
    <myfooter></myfooter>
  </div>
</template>
<script>
import myfooter from '../common/footer.vue'
export default {
  data(){
    return{
      rout:''
    }
  },
  // 生命周期函数，创建
  created(){
    this.rout=this.$route.query.name;
  },
  methods:{
    // 返回数据
    jumpBack(){
      this.$router.push(this.rout)
    },
    jumpCart(){
      this.$router.push('/Cart')
    }
  },
  components:{
    myfooter
  }
}
</script>
<style>
.c_header{
  display:flex;
  height:45px;
  line-height:45px;
  background-color:#000;
  width:100%;
}
.c_header div:nth-child(2){
  color:#fff;
  font-size:16px;
  font-weight:bold;
  width:80%;
  text-align:center;
}
.c_header div:first-child{
  width:10%;
  
}
.c_header div:first-child a,.c_header div:last-child a{
  display:block;
  height:45px;
  line-height:45px;
  text-align:center;
}
.c_header div:first-child a span,.c_header div:last-child a span{
  display:block;
  height:45px;
  line-height:46px;
  color:#fff;
}
.c_header div:last-child{
  width:10%;
  text-align:left;
} 
.chat_content{
  background-color:#fff;
  text-align:center;
  height:55px;
  line-height:55px;
  font-size:16px;
  color:#929292;
}
</style>
