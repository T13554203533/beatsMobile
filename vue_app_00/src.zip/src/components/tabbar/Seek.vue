<template>
  <div id='seek'>
    <div class="seekHeader">
      <div @click='jumpBack'>
        <a><span class="mui-icon mui-icon-back"></span></a>
      </div>
      <div>
        <input placeholder='宝贝关键字' v-model="keyword">
      </div>
      <div @click="searchGoods">
        <a><span class="mui-icon mui-icon-search"></span></a>
      </div>
    </div>
    <ul class="mui-table-view total">
    <li class="mui-table-view-cell" @click='jumpToList'>
        <a class="mui-navigate-right">全部宝贝</a>
    </li>
    </ul>
    <ul class="mui-table-view text-style">
    <li @click='jumpList(item.sid)' class="mui-table-view-cell" v-for='item of seekList' :key='item.sid'>
        <a class="mui-navigate-right">【{{item.sname}}】</a>
    </li>
</ul>
  </div>
</template>
<script>
export default {
  data(){
    return{
      rName:'',
      seekList:[
        {sid:0,sname:'新品推荐'},
        {sid:1,sname:'头戴式耳机'},
        {sid:2,sname:'入耳式耳机'},
        {sid:3,sname:'无线耳机'},
        {sid:4,sname:'降噪耳机'},
        {sid:5,sname:'音箱'},
        {sid:6,sname:'所有商品'}
        ],
      keyword:''
    }
  },
  created(){
    this.rName=this.$route.query.name
  },
  methods:{
    searchGoods(){
      this.$router.push('/list?sname='+this.keyword)
    },
    // 跳转到商品列表
    jumpToList(){
      this.$router.push('/List')
      },
      // 商品分类模糊查询
      jumpList(i){
        var n=this.seekList[i].sname
        this.$router.push('/List?sname='+n)
      },
      // 返回商品列表页面或则首页
      jumpBack(){
        this.$router.push(this.rName)
      },    
  }
}
</script>
<style>
  #seek .seekHeader{
    width:100%;
    height:45px;
    display:flex;
    background-color:#fff;
  }
  #seek .seekHeader div:first-child{
    width:10%;
    height:100%;
  }
  #seek .seekHeader div:first-child a span{
    display:inline-block;
    height:45px;
    line-height:45px;
    width:100%;
    color:#666;
    font-size:32px;
    text-align:center;
  }
  #seek .seekHeader div:last-child{
    width:12%;
    height:100px;
  }
  #seek .seekHeader div:nth-child(2){
    width:78%;
    height:100%;
    line-height:46px;
  }
  #seek .seekHeader div:nth-child(2) input{
    height:30px;
    margin:0;padding:0;
    background:#eee;
    outline:0;
    border:0;
    font-size:13px;
    padding-left:5px;
    width:100%;
    border-radius:5px;
  }
  /* 搜索框获得鼠标焦点时的样式 */
  #seek .seekHeader div:nth-child(2) input:focus{
    box-shadow: 0px 0px 1px 1px #2796dd;
  } 
  #seek .total{
    margin-top:5px;
    margin-bottom:5px;
    color:#666;
    font-size:14px;
  }
  #seek .seekHeader div:last-child a span{
    display:inline-block;
    height:45px;
    line-height:45px;
    width:100%;
    color:#666;
    font-size:28px;
    text-align:center;
  }
  #seek .mui-navigate-right:after, .mui-push-left:after, .mui-push-right:after{
    font-size:21px;
    color:#5f656e;
  }
  #seek ul.text-style li a{
    color:#666;
    font-size:14px;
  }
</style>
