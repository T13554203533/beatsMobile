<template>
  <div class="index"> 
    <!-- 头部 -->
    <header id="header">
      <div class="header_content">
        <div class="header_top" @click='jumpToSeek'>
          <p>分类</p>
          <p>.&nbsp;.&nbsp;.</p>
        </div>
        <div class="header_bottom">
          <a @click='jumpToIntroduce'>
          <img src="../../img/index_img/logo.png" alt="">
          </a>
          <div class="shop_name">
            <p>beats官方旗舰店</p>
            <p>品牌旗舰店</p>
          </div>
          <div class="header_number header_col_com">
              <p>229.1万</p>
              <p>粉丝</p>
            </div> 
          <div class='header_collet header_col_com' @click='collect'>
            <p v-if='iscollect'>收藏</p>
            <p v-else>已收藏</p>
          </div>
        </div>
      </div>
    </header>
    <!-- 导航模块 -->
    <nav class="shop_nav" id="nav">
			<a href='javascript:;'>
        <img src="../../img/index_img/home.png" alt="">
        <span>首页</span>
      </a>
      <router-link to='/list'>
        <img src="../../img/index_img/product.png" alt="">
        <span>全部商品</span>
      </router-link>
      <a href='javascript:;' @click="jumpToNew">
        <img src="../../img/index_img/new.png" alt="">
        <span>新品</span>
      </a>
      <a href='javascript:;' @click='jumpToInteract'>
        <img src="../../img/index_img/play.png" alt="">
        <span>互动</span>
      </a>
    </nav>
    <!-- 搜索框 -->
    <div class="index_search" @click='jumpToSeek'>
      <span class="mui-icon mui-icon-search"></span>
      搜索商品
    </div>
    <!-- 商品种类分类 -->
    <div class="index_classify">
    <div class="shop_type">
      <div>
        <img src="../../img/index_img/9.jpg" alt="">
      </div>
      <div>
        <img src="../../img/index_img/10.png" alt="">
      </div>
      <div>
        <img src="../../img/index_img/11.jpg" alt="">
      </div>
      <div>
        <img src="../../img/index_img/47.jpg" alt="">
      </div>
      <div>
        <img src="../../img/index_img/48.png" alt="">
      </div>
    </div>
    <div class="index_gather">
      <img src="../../img/index_img/12.png" alt="">
    </div> 
  </div>
  <!-- 商品精选 -->
  <div class="index_exce">
    <img src="../../img/index_img/55.png" alt="">
  </div>
  <!-- 商品轮播 -->
<!-- <mt-swipe :auto="4000" id="carousel">
  <mt-swipe-item v-for="(item,i) of carousel" :key='i'>
    <img :src="item" alt="">
  </mt-swipe-item> 
</mt-swipe> -->
<mt-swipe :auto="4000">
        <mt-swipe-item>
          <img src="../../img/index_img/4.jpg" alt="">
        </mt-swipe-item>
        <mt-swipe-item>
          <img src="../../img/index_img/5.jpg" alt="">
        </mt-swipe-item>
        <mt-swipe-item>
          <img src="../../img/index_img/6.jpg" alt="">
        </mt-swipe-item>
      </mt-swipe>
<!-- 头戴式耳机 -->
  <div class="index_head">
    <img src="../../img/index_img/17.jpg" alt="">
    <img src="../../img/index_img/15.png" alt="">
    <img src="../../img/index_img/16.png" alt="">
  </div>
  <div class="index_head_primary">
    <div class="primary_item">
      <img src="../../img/index_img/18.png" alt="">
    </div>
    <div class="primary_pointer">
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_1"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_2"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_3"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_4"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_5"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_6"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_7"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_8"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_9"></div>
      </div>
  </div>
  </div>
  <!-- 入耳式耳机 -->
  <div class="index_head">
    <img src="../../img/index_img/27.jpg" alt="">
    <img src="../../img/index_img/28.png" alt="">
    <img src="../../img/index_img/29.png" alt="">
  </div>
  <div class="index_ear">
    <div class="ear_item">
      <img src="../../img/index_img/30.png" alt="">
    </div>
    <div class="ear_pointer">
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="color_ear_1"></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div></div>
      </div>  
  </div>
  </div>
  <!-- 蓝牙耳机 -->
  <div class="index_head">
    <img src="../../img/index_img/33.jpg" alt="">
    <img src="../../img/index_img/34.png" alt="">
    <img src="../../img/index_img/35.png" alt="">
  </div>
  <div class="index_ear">
    <div class="ear_item">
      <img src="../../img/index_img/36.png" alt="">
    </div>
    <div class="ear_pointer">
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div></div>
      </div>
      <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="booth_red"></div>
      </div>  
       <div>
        <img src="../../img/index_img/32.png" alt="">
        <div class="booth_white"></div>
      </div>
  </div>
  </div>
  <!--  -->
  <div class="index_infor">
    <img src="../../img/index_img/39.jpg" alt="">
    <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_infor">
    <img src="../../img/index_img/41.jpg" alt="">
     <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_infor">
    <img src="../../img/index_img/42.jpg" alt="">
     <img src="../../img/index_img/40.png" alt="">
  </div>
  <div class="index_kind">
    <img src="../../img/index_img/43.jpg" alt="">
    <img src="../../img/index_img/44.jpg" alt="">
    <img src="../../img/index_img/45.jpg" alt="">
  </div>
  <div class="index_brand">
    <img src="../../img/index_img/46.jpg" alt="">
  </div>
  <!-- <div class="index_button">
    <mt-button block>查看所有商品</mt-button>
  </div> -->
  <!--  -->
  <button class="mint-button mint-button--large" @click="jumpToList">
    <label>查看所有宝贝</label>
  </button>
  <!-- 底部导航footer组件 -->
  <myfooter></myfooter>
  <!-- <div class='index_bottom'>
    <div></div>
    <ul>
      <li>登录</li>
      <li>|</li>
      <li>店铺首页</li>
      <li>|</li>
      <li>下载客户端</li>
    </ul>
  </div> -->
  <!-- 底部导航 -->
  <nav class="mui-bar mui-bar-tab">
			<router-link class="bar-item" to="/list">	
				<span class="mui-tab-label">宝贝分类</span>
			</router-link>
			<a class="bar-item" href="javascript:;" @click='jumpToIntroduce'>		
				<span class="mui-tab-label">店铺介绍</span>
			</a>
			<a class="bar-item" href="javascript:;" @click='jumpToChat'>	
				<span class="mui-tab-label">联系我们</span>
			</a>
		</nav>
  </div>
</template>
<script>
// 引入组件，自定义标签名称
import myfooter from '../common/footer.vue'
export default {
  data() {
    return {
      iscollect:false
    }
  },
  created(){
  },
  methods:{
    // 跳转到客服交流组件
    jumpToChat(){
      this.$router.push('/Chat?name=Home')
    },
    // 跳转到互动组件
    jumpToInteract(){
      this.$router.push('/Interact?name=Home')
    },
    // 跳转到搜索组件
    jumpToSeek(){
      this.$router.push('/Seek?name=Home')
    },
    // 商品列表
    jumpToList(){
      this.$router.push("/list")
    },
    // 店铺介绍跳转
    jumpToIntroduce(){
      this.$router.push('/Introduce')
    },
    collect(){
    if(this.iscollect==true){
      this.iscollect=false
    }else{
      this.iscollect=true
    }
    },
    // 跳转到新上页面
    jumpToNew(){
      this.$router.push('/New')
    }
  },
  // 作为home.vue的子组件
  components:{
    myfooter
  }
}
</script>
<style>
  /* 头部样式 */
  body,.app-container{
    font-size:62.5%;
  }
  .index #header .header_content{
    /* width:100%; */
    height:118px;
    background-color:rgba(0,0,0,0.4)
  }
  .index #header{
    position:relative;
    background-image:url('../../img/index_img/14.jpg');
  }
  .app-container{
    margin:0;padding:0;
  }
  #header .header_top{
    width:100%;
    height:52px;
  }
  #header .header_top p:first-child{
    position:absolute;
    right:45px;
    top:14px;
    font-size:16px;
    color:#fff;
    z-index:99
  }
  #header .header_top p:last-child{
    position:absolute;
    right:20px;
    top:16px;
    font-weight:bold;
    color:#fff;
  }
  #header .header_bottom{
    width:100%;
    height:66px;
  }
  #header .header_bottom img{
    width:66px;height:66px;
    position:absolute;
    bottom:0px;left:0px;
  }
  #header .shop_name{
    position:absolute;
    left:75px;
    width:184px;
    height:47px;
    top:59px;
  }
  #header .shop_name p:first-child{
    height:27px;
    line-height:27px;
    font-size:14px;
    color:#fff;
    /* 文字不换行 */
    white-space:nowrap;
    text-overflow:ellipsis;
    /* 超出边框的文字用...代替 */
    margin:0px;
  }
  #header .shop_name p:last-child{
    background-color:#dd2727;
    border-radius:2px;
    color:#fff;
    padding:2px 3px;
    font-size:12px;
    line-height:12px;
    width:67px;
    white-space:nowrap;
    text-overflow:ellipsis;
  }
  #header .header_collet{
    font-size:14px;
    background-color:#dd2727;
  }
  #header .header_collet p:first-child{
    color:#fff;
    line-height:46px;
  }
  #header .header_collet p:last-child{ 
    color:#fff;
    line-height:46px;
  }
  #header .header_col_com{
    width:58px;
    height:46px;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    float:right;
    text-align:center;
  }
  #header .header_number{
    background-color:#d0021b;
    padding-top:6px;
  }
  #header .header_number p{
    margin:0;
    padding:0;
    color:#fff;
    height:18px;
    font-size:12px;
  }
  /* 导航样式 */
 .index .shop_nav{
   width:100%;
   height:60px;
   position:relative;
   overflow:hidden;
   text-overflow:ellipsis;
   white-space:nowrap;
   display:table;
   background-color:#fff;
   border-top: 1px solid rgba(0,0,0,.1);
   border-bottom: 1px solid rgba(0,0,0,.1);
 }
  .index .shop_nav img{
    position:absolute;
  }
  .index .shop_nav img:first-child{
    left:50%;
    top:32%;
    margin-left:-11px;
    margin-top:-11px;
  }
  .index .shop_nav a:first-child span{
    color:rgb(221,39,39);
  }
  .index .shop_nav a:first-child{
    border-bottom:2px solid red;
  }
  .index .shop_nav span{
    display:inline-block;
    padding-top:28px;
    font-size:16px;
    color:#000;
  }
  .index .shop_nav a{
    display:table-cell;
    vertical-align:middle;
    white-space:nowrap;
    text-overflow:ellipsis;
    position:relative;
    text-align:center;
    width:25%;
  }
  /* 搜索框样式 */
  .index .index_search{
    height:40px;
    border-radius:2px;
    color:#a9a9a9;
    line-height:40px;
    font-size:13px;
    text-align:center;
    background-color:#fff;
    border:none;
    margin:6px;
  }
  /* 耳机分类样式 */
  .index .index_classify{
    width:100%;
  }
  .index .shop_type{
    display:flex;
    position:relative;
    box-sizing:border-box;
    align-content:flex-start;
    justify-content:flex-start;
    background-color:transparent;
    overflow:scroll;
    width:145%;
  }
  .index .shop_type div img{
    width:100%;
  }
  .index .shop_type div{
    box-sizing:border-box;
    border-left:1px solid #fff;
    width:33%;
  }
  .index .index_gather{
    position:absolute;
    top:0;
    right:0;
    background-color:#000;
    z-index:100;
    width:12%;
    height:80%;
    box-sizing:border-box;
    overflow:hidden;
  }
  .index .index_gather img{
    width:100%;
  }
  .index .index_classify{
    position:relative;
  }
  .index .index_exce{
    padding:1%;
    width:100%;
    background-color:#fff;
  }
  .index .index_exce img{ 
    width:100%;
  }
  /* 轮播图样式 */
   .index div.mint-swipe{
     width:100%;
     height:275px;
  } 
  .index div.mint-swipe-item{
     width:100%;
     height:275px;
  }
  .index .mint-swipe-item img{
    display:block;
    overflow:hidden;
    width:100%;
    height:100%;
  }
  /* 头戴式耳机样式 */
  .index .index_head{
    box-sizing:border-box;
    width:100%;
  }
  .index .index_head img{
    width:100%;
  }
  .index .primary_item{
    width:100%;
    box-sizing:border-box;
    overflow:hidden;
  }
  .index .primary_item img{
    width:100%;
  }
  .index .index_head_primary{
    box-sizing:border-box;
    width:100%;
    overflow:hidden;
    height:auto;
  }
  .index .primary_pointer{
    display:flex;
    justify-content:space-around;
    box-sizing:border-box;
    width:126%;
  }
  .index .primary_pointer>div{
    width:8%;
    box-sizing:border-box;
    text-align:center;
    position:relative;
  }
  .index .primary_pointer img{
    width:100%;
  }
  .index .primary_pointer div div{
    width:81%;
    height:68%;
    background-color:#000;
    position:absolute;
    border-radius:50%;
    top:7%;
    left:10%;
  }
  .index .index_head_primary div div.color_2{
    background-color:rgb(242,217,195);
  }
  .index .index_head_primary div div.color_3{background-color:rgb(201,223,234)}
  .index .index_head_primary div div.color_4{background-color:rgb(125,126,128)}
  .index .index_head_primary div div.color_5{background-color:rgb(96,98,99)}
  .index .index_head_primary div div.color_7{background-color:rgb(255,255,255)}
  .index .index_head_primary div div.color_8{background-color:rgb(53,70,98)}
  .index .index_head_primary div div.color_9{background-color:rgb(190,52,57)}
  .index .index_ear{
    box-sizing:border-box;
    width:100%;
    overflow:hidden;
    height:auto;
  }
  .index .ear_item img{
    width:100%;
  }
  .index .ear_pointer{
    display:flex;
    justify-content:center;
    box-sizing:border-box;
    width:100%;
  }
  .index .ear_pointer img {
    width:100%;
  }
  .index .ear_pointer div{
    width:10%;
    box-sizing:border-box;
    text-align:center;
    position:relative;
    margin-left:3%;
  }
  .index .ear_pointer div div{
    width:81%;
    height:71%;
    background-color:#000;
    position:absolute;
    border-radius:50%;
    top:7%;
    left:7%;
  }
  .index .ear_pointer div div.color_ear_1{
    background-color:#a9a9a9;
  }
  .index .ear_pointer div div.booth_red{
    background-color:#d0021b;
  }
  .index .ear_pointer div div.booth_white{
    background-color:#fff;
  }
  /* 分类 */
  .index .index_infor{
    width:100%;
    box-sizing:border-box;
    position:relative;
  }
  .index .index_infor img{
    width:100%;
  }
  .index .index_infor img:nth-child(2){
    position:absolute;
    width:30%;
    bottom:14%;
    left:35%;
  }
  /* 品牌资讯 */
  .index .index_kind{
    display:flex;
    box-sizing:border-box;
    justify-content:space-between;
    width:100%;
  }
  .index .index_kind img{
    width:31%;
    height:100%;
  }
  .index .index_brand{
    width:100%;
    box-sizing:border-box;
    margin-top:4%;
  }
  .index .index_brand img{
    width:100%;
  }
  /* 底部查看所有商品样式 */
  .index .index_button{
    width:100%;
    background-color:#fff;
  }
  .index .mint-button{
    color:#a9a9a9;
    font-size:1rem;
  }
  /* 页尾样式 */
  /* .index .index_bottom{
    width:100%;
    height:100px;
    background-color:#fff;
  }
  .index .index_bottom div{
    border-bottom:2px solid #000;
    width:100%;
  }
  .index .index_bottom ul{
    list-style:none;
    display:flex;
    justify-content:center;
    text-align:center;
    white-space:nowrap;
    text-overflow:ellipsis;
    padding:0;
  }
  .index .index_bottom ul li {
    width:15%;
    color:#a9a9a9;
  } */
  /* 底部导航样式 */
  .index .mui-bar{
    box-shadow:0 0 0 0 ;
    border-top:1px solid rgb(229,229,229);
    border-bottom:1px solid rgb(229,229,229);
  }
  .index .bar-item{
    display:table-cell;
    background-color:#fff;
    font-size:15px;
    color:#000;
    text-align:center;
    vertical-align:middle;
  }
  .index .bar-item:not(:last-child){
    border-right:1px solid rgb(229,229,229);
  }
</style>
