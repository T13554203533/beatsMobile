<template>
  <div id="new">
     <header class="topHeader">
      <div>
       <a id="icon-home" @click="jumpHome"><span class="mui-icon mui-icon-home"></span></a>
      </div>
      <div>
        <p style="font-weight:bold;">beats官方旗舰店-上新</p>
      </div>
      <div @click="ishide">
        <a id="icon-more" style="color:#929292;text-align:right;">
          <span class="mui-icon mui-icon-more"></span>
          </a>
      </div>
      <div id="hide" v-show="hide>100">
            <p @click="jumpCart"><a><span class="mui-icon-extra mui-icon-extra-cart"></span><span>购物车</span></a></p>
            <p @click='jumpHome'><a id="icon-home"><span class="mui-icon mui-icon-home"></span><span>首页&nbsp;&nbsp;&nbsp;</span></a></p>
          </div>
    </header>
    <div class="Newcontent">
      <p>亲，目前没有新商品哦！</p>
    </div>
    <myfooter></myfooter>
  </div>
</template>
<script>
// 引入组件，自定义标签名称
import myfooter from '../common/footer.vue'
export default {
  data(){
    return{
        hide:50
    }
  },
  methods:{
    jumpHome(){
      this.$router.push('/home')
    },
    // 跳转到购物车
    jumpCart(){
      this.$router.push('/Cart')
    },
    // 右上角隐藏框的显示和隐藏
    ishide(){
      if(this.hide>100){
        this.hide=50
      }else{
        this.hide=150
      }
    }
  },
   components:{
    myfooter
  },
}
</script>
<style>
   .topHeader{
    width:100%;
    height:44px;
    display:flex;
    flex-wrap:nowrap;
    align-items: center;
    background-color:#000;
    color:#fff;
    font-size:16px;
    box-sizing: border-box;
    position:relative;
  }
   .topHeader div:first-child{
    width:15%;
    text-align:center;
  }
   .topHeader div:first-child a span{
    color:#fff;
    font-size:28px;
  }
   .topHeader div a{color:#fff;}
   .topHeader div:nth-child(2){
    margin:0;padding:0;
    width:70%;
    height:100%;
    line-height: 44px;
    text-align: center;
  }
   .topHeader div:nth-child(2) p{
    color:#fff;
    font-size:16px;
    line-height: 44px;
    margin:0;
  }
  .topHeader div:last-child{
    text-align: center;
    width:15%;
  }
   #hide{
    width:120px;
    height:89px;
    position:absolute;
    z-index:20;
    right:2%;
    top:36px;
    background: rgba(51,51,51,.95);
    border-radius:2px;
    overflow:hidden;
  }
   #hide p{
    height:44px;
    line-height:44px;
    margin:0;
    color:#929292;
  }
   #hide p a{display:flex;justify-content:center;
    align-items: center;
    text-align:center;
  }
   #hide p a span:last-child{
    padding-left:10px;
  }
   #hide p span{color:#ccc;}
   #new .Newcontent{
     background-color:#fff;
     height:50px;
     text-align:center;
     line-height:50px;
   }
   #new .Newcontent p{margin:0;font-size:16px;}
</style>
