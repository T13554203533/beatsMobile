<template>
  <div id="Introduce">
    <!-- 店铺介绍页面：头部 -->
    <header class="topHeader">
      <div>
       <a id="icon-home" @click="jumpHome"><span class="mui-icon mui-icon-home"></span></a>
      </div>
      <div>
        <p>店铺介绍</p>
      </div>
      <div @click="ishide">
        <a id="icon-more" style="color:#929292;text-align:right;">
          <span class="mui-icon mui-icon-more"></span>
          </a>
      </div>
      <div id="hide" v-show="hide>100">
            <p @click="jumpCart"><a><span class="mui-icon-extra mui-icon-extra-cart"></span><span>购物车</span></a></p>
            <p @click='jumpHome'><a id="icon-home"><span class="mui-icon mui-icon-home"></span><span>首页&nbsp;&nbsp;&nbsp;</span></a></p>
          </div>
    </header>
    <!--主体内容  -->
    <div class="content">
      <!-- 主体内容第一部分 -->
      <div class="content_top">
        <div class="store_img">
          <div>
          <img src="@/img/introduce_img/i1.png" alt="">
          </div>
        </div>
        <div class="top_name">
          <p style="color:#000;font-weight:bold;">beats官方旗舰店</p>
          <div style="text-align:left;" @click='collect'>
            <a id="icon-star" v-if='isCollect'><span class="mui-icon mui-icon-star"></span><span>收藏</span></a>
              <a v-else class="name_item"><span class="mui-icon-extra mui-icon-extra-like"></span><span>已收藏</span></a> 
          </div>
        </div>
      </div>
      <!-- 服务情况：二层 -->
      <ul class="serve">
        <li>
          <p class="serve_item"><span>4.8</span><span></span></p>
          <p>描述相符</p>
        </li>
        <li>
          <p><span>4.8</span><span style="border-color:#ec1d1d"></span></p>
          <p>服务态度</p>
        </li>
        <li>
          <p><span>4.8</span><span style="border-color:#ec1d1d"></span></p>
          <p>物流服务</p>
        </li>
      </ul>
      <!-- 店铺介绍：三层 -->
      <div class="address">
        <span>所在地区：</span><span>广东&nbsp;深圳</span>
      </div>
      <!-- 店铺介绍：四楼 -->
      <div class="address chat">
        <span>掌柜：</span><span>beats官方旗舰店</span><a class="chat_icon" @click='jumpToChat'><span class="mui-icon mui-icon-chat"></span></a>
      </div>
    </div>
    <!-- 页尾 -->
    <myfooter></myfooter>
  </div>
</template>
<script>
import myfooter from '../common/footer.vue'
export default {
  data(){
    return{
      isCollect:true,
      hide:50
    }
  },
  components:{
    myfooter
  },
  methods:{
    // 跳转到交谈组件
    jumpToChat(){
      this.$router.push('/Chat?name=Introduce')
    }, 
    // 是否收藏
    collect(){
      if(this.isCollect===true){
        this.isCollect=false
      }else {
        this.isCollect=true
      }
    },
    // 跳转到首页
    jumpHome(){
      this.$router.push('/home')
    },
    // 跳转到购物车
    jumpCart(){
      this.$router.push('/Cart')
    },
    // 右上角隐藏框的显示和隐藏
    ishide(){
      if(this.hide>100){
        this.hide=50
      }else{
        this.hide=150
      }
    }
  }
}
</script>
<style scoped>
  /* 1.店铺介绍组件：--头部样式 */
  #Introduce .topHeader{
    width:100%;
    height:44px;
    display:flex;
    flex-wrap:nowrap;
    align-items: center;
    background-color:#000;
    color:#fff;
    font-size:16px;
    box-sizing: border-box;
    position:relative;
  }
  #Introduce .topHeader div:first-child{
    width:15%;
    text-align:center;
  }
  #Introduce .topHeader div:first-child a span{
    color:#fff;
    font-size:28px;
  }
  #Introduce .topHeader div a{color:#fff;}
  #Introduce .topHeader div:nth-child(2){
    margin:0;padding:0;
    width:70%;
    height:100%;
    line-height: 44px;
    text-align: center;
  }
  #Introduce .topHeader div:nth-child(2) p{
    color:#fff;
    font-size:16px;
    line-height: 44px;
    margin:0;
  }
  #Introduce .topHeader div:last-child{
    text-align: center;
    width:15%;
  }
  #Introduce #hide{
    width:120px;
    height:89px;
    position:absolute;
    z-index:20;
    right:2%;
    top:36px;
    background: rgba(51,51,51,.95);
    border-radius:2px;
    overflow:hidden;
  }
  #Introduce #hide p{
    height:44px;
    line-height:44px;
    margin:0;
    color:#929292;
  }
  #Introduce #hide p a{display:flex;justify-content:center;
    align-items: center;
    text-align:center;
  }
  #Introduce #hide p a span:last-child{
    padding-left:10px;
  }
  #Introduce #hide p span{color:#ccc;}
  /* 页面主体内容样式 */
  /* 一层 */
  #Introduce .content{
    background-color:#fff;
  }
  #Introduce .content_top{
    width:80%;
    height:102px;
    display:flex;
    margin:0 auto;
    border-bottom:1px solid #CCC;
    justify-content: center;
  }
  #Introduce .content_top .store_img{
    height:100%;
    width:100px;
  }
  #Introduce .content_top .store_img div{
    width:75%;
    height:75%;
    border:1px solid rgba(0,0,0,0.35);
    margin-top:12.5%;
    margin-left:12.5%;
    border-radius:50%;
    overflow:hidden;
  }
  #Introduce .content_top .store_img img{
    width:100%;
  }
  #Introduce .content_top .top_name div{
    font-size:16px;
    color:#929292;
    border: 1px solid #929292;
    border-radius:2px;
    line-height:100%;
    text-align:center;
    width:90px;
    padding:3px;
  }
  #Introduce .content_top .top_name div #icon-star{
    color:#929292;
  }
  #Introduce .content_top .top_name div .name_item{
    color:#ec1d1d;
  }
  #Introduce .content_top .top_name div span{
    margin-left:5px;
  }
  #Introduce .content_top .top_name{
    height:102px;
    vertical-align: center;
    width:50%;
    margin-left:10px;
  }
  #Introduce .content_top .top_name p{
    font-size:16px;
    color:#929292;
    margin-top:15%;
    height:22px;
    line-height: 22px;
  }
  /* 服务评分：二层 */
  #Introduce ul.serve{
    width:80%;
    margin:auto;
    display:flex;
    justify-content:space-between;
    list-style:none;
    height:60px;
    border-bottom:1px solid #CCC;
    text-align:center;
    font-size:14px;
  }
  #Introduce ul.serve li{
    height:100%;
  }
  #Introduce ul.serve li p{
    margin:0;height:30px;
    line-height:30px;
    padding:2px;
  }
  #Introduce ul.serve li span{color:#ec1d1d;}
  #Introduce ul.serve li .serve_item span{
    color:#2796dd;
  }
  #Introduce ul.serve li span:last-child{
    border:7px solid #2796dd;
    width:14px;
    height:14px;
    display:inline-block;
    border-radius:50%;
    margin-left:5px;
    margin-top:10px;
  }
  /* 店铺介绍：三楼 *//*  店铺介绍：四楼 */
  #Introduce .address{
    width:80%;margin:0 auto;
    border-bottom:1px solid #ccc;
    height:60px;
    line-height:60px;
    color:#929292;
    font-size:14px;
  }
  #Introduce .address .chat_icon{
    float:right;
    margin-right:15px;
    color:#2796dd;
  }
  #Introduce div.chat{
    box-sizing:border-box;
  }
</style>
