<template>
    <div id="detail"> 
      <!-- 顶部购物车 -->
      <div class="header_top">
        <a @click="jumpToCart"><span class="mui-icon-extra mui-icon-extra-cart"></span></a>
      </div>
      <!-- 顶部商品图片 -->
      <ul class="img_bar">
        <li>
          <img src="../../img/detail_img/t1.jpg" alt="">
        </li>
      </ul> 
      <!-- 商品文字介绍 -->
      <div class="title">
          <div>
            ￥2782
          </div>
          <div>
            【6期免息】Beats Pro 录音师专业版头戴式耳机耳麦
          </div>
          <ul>
            <li>快递 0.00</li>
            <li>月销量 8件</li>
            <li>湖北武汉</li>
          </ul>
      </div>
      <!-- 促销、物流、服务 -->
      <div class="server">
        <ul>
          <li class="integral">
            <p class="in_title">促销</p>
            <p class="in_two">积分</p>
            <p class="in_three">购买可得278积分</p>
            <a class="forward"><span class="mui-icon mui-icon-forward"></span></a>
          </li>
          <li class="integral">
            <p class="in_title">物流</p>
            <p class="address">至大致街街道:</p>
            <p class="in_three">次日达18:00前付款，承诺2日内送达</p>
            <a class="forward"><span class="mui-icon mui-icon-forward"></span></a>
          </li>
          <li class="integral">
            <p class="in_title">物流</p>
            <p class="server_item">正品保证</p>
            <p class="server_item">延保服务</p>
            <p class="server_item">全部联保</p>
            <p class="server_item">极速退款</p>
            <a class="forward"><span class="mui-icon mui-icon-forward"></span></a>
          </li>
        </ul>
      </div>
      <!-- 选择 参数 -->
      <div class="choise">
        <ul>
          <li class="integral">
            <p class="in_title">选择</p>
            <p class="in_three">请选择套餐类型/颜色分类</p>
            <a class="forward"><span class="mui-icon mui-icon-forward"></span></a>
          </li>
          <li class="integral">
            <p class="in_title">参数</p>
            <p class="in_three">品牌型号...</p>
            <a class="forward"><span class="mui-icon mui-icon-forward"></span></a>
          </li>
        </ul>
      </div>
      <!-- 店铺名称 -->
      <div class="shop_info">
        <div class="shopname">
          <p>
          <img src="../../img/index_img/logo.png" alt="">
          </p>
          <p>beats官方旗舰店</p>
        </div>
       <ul class="serve">
        <li>
          <p class="serve_item"><span>4.8</span><span></span></p>
          <p>描述相符</p>
        </li>
        <li>
          <p><span>4.8</span><span style="border-color:#ec1d1d"></span></p>
          <p>服务态度</p>
        </li>
        <li>
          <p><span>4.8</span><span style="border-color:#ec1d1d"></span></p>
          <p>物流服务</p>
        </li>
      </ul>
          <div class="shopbtn">
            <button @click="jumpToList" class="btn1">全部商品</button>
            <button @click="jumpToHome">进入店铺</button>
          </div>
      </div>
      <!-- 详情部分 -->
      <div>
        <div class="particulars">一一 详情 一一</div>
        <div class="subtitle">"6期免息 全国联保 为音乐而生"</div>
      </div>
      <div class="detail_img">
        <img src="../../img/detail_img/c1.jpg" alt="">
        <img src="../../img/detail_img/c2.jpg" alt="">
        <img src="../../img/detail_img/c3.jpg" alt="">
        <img src="../../img/detail_img/c4.jpg" alt="">
        <img src="../../img/detail_img/c5.jpg" alt="">
        <img src="../../img/detail_img/c6.jpg" alt="">
        <img src="../../img/detail_img/c7.jpg" alt="">
        <img src="../../img/detail_img/c8.jpg" alt="">
        <img src="../../img/detail_img/c9.jpg" alt="">
        <img src="../../img/detail_img/c10.jpg" alt="">
        <img src="../../img/detail_img/c11.jpg" alt="">
        <img src="../../img/detail_img/c12.jpg" alt="">
        <img src="../../img/detail_img/c13.jpg" alt="">
        <img src="../../img/detail_img/c14.jpg" alt="">
        <img src="../../img/detail_img/c15.jpg" alt="">
        <img src="../../img/detail_img/c16.jpg" alt="">
        <img src="../../img/detail_img/c17.jpg" alt="">
        <img src="../../img/detail_img/c18.jpg" alt="">
        <img src="../../img/detail_img/c19.jpg" alt="">
        <img src="../../img/detail_img/c20.jpg" alt="">
        <img src="../../img/detail_img/c21.jpg" alt="">
        <img src="../../img/detail_img/c22.jpg" alt="">
        <img src="../../img/detail_img/c23.jpg" alt="">
        <img src="../../img/detail_img/c24.png" alt="">
      </div>
    </div>
</template>
<script>
export default {
  data(){
    return{
      pid:''
    }
  },
  created(){
    this.pid=this.$route.query.pid;
    var url='http://127.0.0.1:3001/Detail?pid='+this.pid;
    this.axios.get(url).then(result=>{
      console.log(result)
    })
  },
  methods:{
    // 跳转到首页
    jumpToHome(){
      this.$router.push('/Home')
    },
    // 跳转到列表
    jumpToList(){
      this.$router.push('/List')
    },
    // 跳转到购物车
    jumpToCart(){
      this.$router.push('/Cart')
    }
  },

}
</script>
<style>
  /* 头部购物车过渡样式 */
  #detail{
    position:relative;
  }
  .header_top{
    width:100%;
    position:absolute;
    height:44px;
    top:0;
    z-index:999;
    background-image:linear-gradient(to bottom,rgba(160,160,160,0.3) 0%,rgba(255,255,255,0.3) 100%);
  }
  .header_top a{
    display:block;
    height:40px;
    width:40px;
    background-color:rgba(146,146,146,0.8);
    border-radius:50%;
    position:relative;
    position:absolute;
    right:5px;
    top:4px;
  }
  .header_top a span{
    color:#fff;
    display:block;
    width:100%;
    height:100%;
    text-align:center;
    line-height:40px;
  }
  /* 头部图片 */
  .img_bar{
    width:100%;
    box-sizing:border-box;
    margin:0;
    padding:0;
  }
  .img_bar li{
    width:100%;
  }
  .img_bar li img{
    width:100%;
  }
  /* 商品标题栏 */
  .title{
    background-color:#fff;
    margin-top:-2%;
  }
  .title div:first-child{
    color:#ff0036;
    font-size:24px;
    top:2px;
    margin-right:5px;
    height:36px;
    line-height:36px;
  }
  .title div:nth-child(2){
    font-size:14px;
    color:#051B28;
    word-break: break-all;
    overflow:hidden;
    height:20px;
    line-height:20px;
  }
  .title ul:last-child{
    display:flex;
    list-style: none;
    justify-content: space-between;
    color:#999999;
    width:96%;
    height:30px;
    line-height:30px;
    margin-left:2%;
  }
  /* 促销，物流，服务 */
  .server{
    width:100%;
    margin:10px 0;
  }
  li.integral{
    display:flex;
    height:45px;
    background-color:#fff;
    position:relative;
  }
  li.integral p{height:45px;line-height:45px;}
  li .in_title{
    height:45px;
    line-height:45px;
    color: #999;
    width: 40px;
    font-size:12px;
    text-align:center;
    margin:0;
  }
  li .forward{
    height:45px;
    line-height:45px;
    color:#CFCFCF;
    position:absolute;
    right:1%;
    font-size:16px;
    font-weight:normal;
  }
  li.integral p.in_two{
    height:20px;
    margin-top:13px;
    transform: scale(.7);
    display: block;
    border: 1px solid #FFF5F7;
    background: #FFF5F7;
    border-radius: 2px;
    padding: 1px 3px;
    font-size: 14px;
    line-height: 1;
    color: #FF0036;
  }
  .in_three{
    color:#051b28;
    font-size:12px;
  }
  .address{
    color:#000;
    font-size:13px;
  }
  .server_item{
    width:15%;
    color:#051b28;
    font-size:12px;
  }
  /* 店铺信息 评分栏 */
   ul.serve{
    width:100%;
    margin:auto;
    display:flex;
    justify-content:center;
    list-style:none;
    height:40px;
    text-align:center;
    font-size:14px;
    background-color:#fff;
  }
   ul.serve li{
    height:100%;
    display:flex;
    justify-content: center;
    width:30%;
  }
  ul.serve li p{
    margin:0;height:30px;
    line-height:30px;
    padding:2px;
  }
   ul.serve li span{color:#ec1d1d;}
   ul.serve li .serve_item span{
    color:#2796dd;
  }
  ul.serve li span:last-child{
    border:7px solid #2796dd;
    width:14px;
    height:14px;
    display:inline-block;
    border-radius:50%;
    margin-left:5px;
    margin-top:10px;
  }
  /* 店铺信息 -logo图片 */
  .shop_info{
    background-color:#fff;
    width:100%;
  }
  .shopname{
    display:flex;
    width:100%;
    box-sizing: border-box;
    margin-top:10px;
  }
  .shopname p img{
    margin:15px 0 0 15px;
    border:1px solid #ccc;
    width:54px;
    }
  .shopname p:last-child{
    margin-left:10px;
     color: #333;
    font-size: 16px;
    text-overflow: ellipsis;
    overflow: hidden;
    word-break: break-all;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    -webkit-box-pack: center;
    display: -webkit-box;
    margin-bottom:0;
  }
  /* 店铺信息 两个按钮 */
  .shopbtn{
    display: flex;
    height:35px;
    justify-content: center;
  }
  .shopbtn button{
    flex: 1;
    border: 1px solid rgba(255,0,54,.5);
    height: 24px;
    line-height: 12px;
    font-size: 13px;
    color: rgba(255,0,54,.8);
    border-radius: 12px;
    text-align: center;
    display: block;
    max-width: 96px;
  }
  .shopbtn .btn1{
    margin-right:10px;
  }
  /* 店铺信心  下详情标题样式 */
  .particulars{
    padding: 0 30%;
    text-align: center;
    font-size:15px;
    color: #999;
    margin:5px 0;
  }
  .subtitle{
    line-height: 28px;
    padding: 10px;
    background: #fff;
    color: #051B28;
    text-align: center;
    overflow: hidden;
    font-size: 16px;
    font-weight: 400;
  }
  /* 详情图片 */
  .detail_img{
    box-sizing: border-box;
    width:100%;
    background-color: #F7F7F7;
  }
  .detail_img img{
    width:100%;
    margin-top:-1.5%;padding:0;
  }
</style>
