<template>
<div id="list">
  <!-- 头部-页头 -->
  <div class="header">
    <div class="flex-container home">
    <router-link id="icon-home" to='home'><span class="mui-icon mui-icon-home"></span></router-link>
    </div>
  <div class="search" @click='jumpToSeek'>
    <input type="text" disabled placeholder='搜索宝贝' v-model="pname">
  </div>
  <div class="flex-container gather">
    <a @click='jumpToSeek'><span class="mui-icon mui-icon-list"></span>
    <span>分类</span></a>
    <p @click='iscover'>
    <a id="icon-more"><span class="mui-icon mui-icon-more"></span></a>
    </p>
  </div>
  <!-- 头部隐藏框 -->
  <div class="cover" v-show='cover_if>100'>
      <div>
        <a><span class="mui-icon-extra mui-icon-extra-cart"></span></a>
        <p>购物车</p>
      </div>
      <div>
        <a id="icon-home"><span class="mui-icon mui-icon-home"></span></a>
        <p>首页</p>
      </div>
  </div>
  </div>
  <div class="header_bar">
    <!-- 头部导航 -->
  <nav class="mui-bar mui-bar-tab">
		    <a class="mui-tab-item mui-active" href="#" @click="totality" :style="colorAll">
		        综合
		    </a>
		    <a class="mui-tab-item" href="#" @click="saleDesc" :style="colorSales">
		        销量
		    </a>
		    <a class="mui-tab-item" href="#" @click='newgoods' :style="colorNew">
		        上新
		    </a>
		    <a class="mui-tab-item" href="#" @click="priceOrder"> 
           <div class="price_asc">
             <p :style="colorPrice">价格</p>
             <div>
             <span :style="orderAsc">▲</span><span :style="orderDesc">▼</span>
             </div>
           </div>
		    </a>
		</nav>
    <!-- 主体内容-商品列表 -->
    <div class="flex-container pattern" @click="mediaList">
      <a v-if="isMedia"><span class="mui-icon-extra mui-icon-extra-class" v-if="isMedia"></span></a>
      <a v-else><span class="mui-icon mui-icon-list" ></span></a>
    </div>
    </div>
    <!-- 商品列表 -->
    <div class="list_product"  v-if="isMedia">
      <div class="pro_item" v-if='item.pid%2!=0' v-for='(item,index) of pro_list' :key="index" @click='jumpToDetail(item.pid)'>
        <a href="javascript:;">
        <img :src="item.pic" alt="">
        <p class="item_title">{{item.title}}</p>
        <div class="item_price">
          <h6>￥{{item.price}}</h6>
          <p>月销{{item.salesVolume}}笔</p>
        </div>
        </a>
      </div>
      <div class="pro_item" v-else @click='jumpToDetail(item.pid)'>
        <a href="javascript:;">
        <img :src="item.pic" alt="">
        <p class="item_title">{{item.title}}</p>
        <div class="item_price">
          <h6>￥{{item.price}}</h6>
          <p>月销{{item.salesVolume}}笔</p>
        </div>
        </a>
      </div>
    </div>
    <!-- 主体内容另一种显示-图文列表 -->
    <ul class="media_table"  v-else>
				<li class="media_item" v-for="(item,index) of pro_list" :key="index">
					<a href="javascript:;">
						<img class="item_img" :src="item.pic">
						<div class="item_text">
							{{item.title}}
              <p class="item_sales">月销{{item.salesVolume}}笔</p>
							<p class="item_price">￥{{item.price}}</p>
						</div>
					</a>
				</li>
			</ul>
    <!-- 加载更多 -->
    <div v-show="show>50" class="nogoods">
      <p>抱歉，没有找到相关商品</p>
    </div>
    <mt-button style="color:#a9a9a9;background-color:#fff;" 
      size="large" @click="loadMore" :disabled="isbtn==false" v-show="show<50">
      {{content}}</mt-button>
    <!-- 页脚组件footer.vue -->
    <myfooter></myfooter>
</div>
</template>
<script>
// 引入组件，自定义标签名称
import myfooter from '../common/footer.vue'
export default {
  data(){
    return{
      cover_if:50,
      pro_list:[],
      pno:1,
      hasMore:true,
      isMedia:true,
      content:'加载更多',
      isbtn:true,
      order:0,
      // 4个变量控制导航文字的颜色
      colorAll:{},
      colorSales:{},
      colorNew:{},
      colorPrice:{},
      orderAsc:{},
      orderDesc:{},
      // 接受seek组件传递过来的值，进行模糊查询
      pname:'',
      show:0
    }
  },
  // 页面加载就发送请求
  created(){
    // 清空所有的样式，只给‘综合’样式添加字体颜色
    this.colorAll.color="#dd2727";
    this.colorSales.color="#929292";
    this.colorNew.color="#929292";
    this.colorPrice.color="#929292";
    this.orderAsc.color="#929292";
    this.orderDesc.color="#929292";
    // 获取seek组件传递过来的值
    // var p=this.$route.query.sname;
    this.pname=this.$route.query.sname;
    this.paramAll()
  },
  components:{
    myfooter
  },
  methods:{
    // 跳转到商品详情组件
    jumpToDetail(i){
      var pid=i;
      this.$router.push(`/Detail?pid=${pid}`)
    },
    // 没有商品时显示什么
    noGoods(){
      if(this.pro_list.length==0){
        this.show=100;
      }else{
        this.show=0;
      }
    },
    // 点击综合查询数据方法，判断此时是否需要向数据传递参数
    paramAll(){
      if(!this.pname){
     var url='http://127.0.0.1:3001/list';
    this.axios.get(url).then(result=>{
      this.pro_list=result.data.data;
      this.hasMore=true;
      this.pno=1;
      this.noGoods()
    })
    }else{
      var url='http://127.0.0.1:3001/list?pname='+this.pname;
      this.axios.get(url).then(result=>{ 
        this.pro_list=result.data;
        this.hasMore=false
        this.noGoods()
      })
    }
    }
    ,
    // 跳转到seek页面
    jumpToSeek(){
      this.$router.push('/Seek?name=List')
    },
    // 右上角隐藏框的显示与隐藏
    iscover(){
      if(this.cover_if>100){
        this.cover_if=50
      }else{
        this.cover_if=150
      }
    },
    // 综合按钮绑定的方法
    totality(){
      this.colorAll.color="#dd2727";
      this.colorSales.color="#929292";
      this.colorNew.color="#929292";
      this.colorPrice.color="#929292";
      this.orderAsc.color="#929292";
      this.orderDesc.color="#929292";
      this.isbtn=true;
      this.content='加载更多';
    //   var url='http://127.0.0.1:3001/list';
    // this.axios.get(url).then(result=>{
    //   //  console.log(result)
    //   this.pro_list=result.data.data;
    //   // console.log(this.pro_list)
    //   this.hasMore=true;
    //   this.pno=1;
    // })
    this.paramAll()
    },
    // 加载更多方法调用
    loadMore(){
      if(this.hasMore==false){
        this.$toast('没有更多商品了')
        this.content='已显示全部商品 -_-||'
        return;
      }
      this.pno++;
      var url='http://127.0.0.1:3001/list?pno='+this.pno;
      this.axios.get(url).then(result=>{
        // console.log(result);
        // if(this.pno>=result.data.pageSize){
          if(this.pro_list.length>=20){
          this.hasMore=false;
        }
        // console.log(result.data.data)
        this.pro_list=this.pro_list.concat(result.data.data);
      })
    },
    // 控制图文列表的两种显示方式的切换
    mediaList(){
      if(this.isMedia===true)
      {this.isMedia=false;}
      else{
      this.isMedia=true;}
    },
    // 月销量降序选项，一次性查出数据库中的所有数据，禁用下面的加载更多按钮
    saleDesc(){
      this.colorAll.color="#929292";
      this.colorSales.color="#dd2727";
      this.colorNew.color="#929292";
      this.colorPrice.color="#929292";
      this.orderAsc.color="#929292";
      this.orderDesc.color="#929292";
      var url='';
      if(!this.pname){
      url='http://127.0.0.1:3001/list/sales';
      }else{
        url='http://127.0.0.1:3001/list/sales?pname='+this.pname;
      }
      this.axios.get(url).then(result=>{
        // console.log(result)
        this.pro_list=result.data;
      })
      this.content='已显示全部商品 -_-||';
      this.isbtn=false;
    },
    // 新上-根据上架时间获取商品列表
    newgoods(){
      this.colorAll.color="#929292";
      this.colorSales.color="#929292";
      this.colorNew.color="#dd2727";
      this.colorPrice.color="#929292";
      this.orderAsc.color="#929292";
      this.orderDesc.color="#929292";
      var url='';
      if(!this.pname){
      url='http://127.0.0.1:3001/list/new';
      }else{
        url='http://127.0.0.1:3001/list/new?pname='+this.pname;
      }
      this.axios.get(url).then(result=>{
          this.pro_list=result.data;
      })
    },
    // 根据价格的升序和降序获取商品列表
    priceOrder(){
      var url="";
      this.order++;
      if(this.order%2!=0){
      this.colorAll.color="#929292";
      this.colorSales.color="#929292";
      this.colorNew.color="#929292";
      this.colorPrice.color="#dd2727";
      this.orderAsc.color="#dd2727";
      this.orderDesc.color="#929292";
      }else{
      this.orderAsc.color="#929292";
      this.orderDesc.color="#dd2727";
      }
      if(!this.pname){
       url='http://127.0.0.1:3001/list/price?num='+this.order;
      }else{
        url='http://127.0.0.1:3001/list/price?num='+this.order+'&'+'pname='+this.pname;
      }
      this.axios.get(url).then(result=>{
        this.pro_list=result.data;
      })
    },
  }
}
</script>
<style>
*{
  margin:0;padding:0;
}
#list .flex-container a{
  color:#fff;
}
#list .header{
  background-color:#000;
  display:flex;
  flex-wrap:nowrap;
  width:100%;
  height:50px;
  position:relative;
}
/* 隐藏框样式cover */
#list .cover{
  position:absolute;
  width:120px;
  height:89px;
  right:2%;
  top:40px;
  background-color:rgba(51,51,51,.95);
  z-index:200;
  border-radius:3px;
}
#list .cover div{
  display:flex;
  justify-content: space-around;
  text-align:center;
}
#list .cover div a{
  display:inline-block;
  width:35%;
  text-align:center;
  height:44px;
  line-height:44px;
  color:#929292;
}
#list div.cover #icon-home .mui-icon{font-size:24px;}
#list .cover div p{
  height:44px;
  width:65%;
  line-height:44px;
  margin:0;
  text-align:left;
  font-size:15px;
}
#list .header .home{
  width:15%;
  text-align:center;
  vertical-align:middle;
}
#list #icon-home .mui-icon{
  font-size:30px;
  margin-top:10px;;
}
#list #icon-home{
  height:100%;
}
#list .search{
  vertical-align: middle;
  /* padding-top:10%; */
  width:65%;
  /* height:100%; */
}
#list .search input{
  display:block;
  margin:0;
  margin-top:8px;
  height:68%;
  padding:0;
  padding-left:11%;
  border:0;
  background:#fff url('../../img/index_img/13.png') no-repeat left center;
  color:#000;
  font-size:15px;
}
#list .gather{
  display:flex;
  flex-wrap:nowrap;
  justify-content:center;
  width:20%;
}
#list .gather a:first-child{
  display:flex;
  flex-direction:column;
  text-align:center;
  padding-top:5px;
  font-size:13px;
  justify-content: space-around;
  width:50%;
}
#list .gather a:last-child{
  text-align:left;
  width:50%;
  padding-top:10%;
  color: #a9a9a9;
}
#list .gather a:last-child span{
  display:inline-block;
}
#list .mui-bar-tab{
  top:50px;
  width:86%;
}
#list .header_bar{
  height:52px;
  width:100%;
}
#list .mui-bar{
  box-shadow:0 0 0 0 ;
  font-size:15px;
  height:45px;
  background-color:#fff;
  position:absolute;
}
#list .mui-bar-tab .mui-tab-item.mui-active{
  color:#DD2727;
}
#list .mui-bar a:last-child{
  text-align:center;
}
#list .mui-bar .price_asc{
  display:flex;
  height:100%;
  margin:0;padding:0;
  text-align:right;
  width:100%;
  justify-content: center;
}
#list .mui-bar .price_asc div{
  display:flex;
  flex-direction:column;
  align-items: center;
  box-sizing:border-box;
  line-height:26px;
  vertical-align: middle;
  position:relative;
}
#list .mui-bar .price_asc div span{
  display:inline-block;
  height:22%;
  font-size:10px;
  align-self: center;
  position:absolute;
}
#list .mui-bar .price_asc div span:first-child{top:9px;left:0;}
#list .mui-bar .price_asc div span:last-child{top:18px;left:0;}
#list .mui-bar .price_asc p{
  margin:0;
  line-height:52px;
  font-size:15px;
  padding-right:2%;
}
#list .pattern{
  width:14%;
  height:52px;
  margin-left:86%;
  background-color:#fff;
  box-sizing:border-box;
  border-left:1px solid #E5E5E5;
  text-align:center;
  line-height:58px;
}
#list .pattern a{
  color:#8F8F94;
}
#list .list_product{
  margin-top:5px;
  width:100%;
  display:flex;
  flex-wrap:wrap;
}
#list .list_product>div.pro_item{
  width:49.5%;
  box-sizing:border-box;
  background-color:#fff;
}
#list .list_product>div.pro_item:nth-child(2n){
  margin-left:1%;
  margin-bottom:1%;
}
#list .list_product>div.pro_item:nth-child(2n+1){
  margin-bottom:1%;
}
#list .list_product>div img{
  width:100%;
}
#list .item_title{
    font-size: 12px;
    line-height: 18px;
    color: #333;
    height: 36px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    word-wrap: break-word;
    overflow: hidden;
}
#list .item_price{
  display:flex;
  flex-wrap:nowrap;
  justify-content: space-between;
}
#list .item_price h6{
    font-size: 14px;
    font-weight: 700;
    color: #dd2727;
    height: 28px;
    line-height: 28px;
    margin:0;
    padding-left:4%;
    text-overflow:ellipsis;
    white-space:nowrap;
}
#list .item_price p{
    font-size: 12px;
    color: #999;
    height: 28px;
    line-height: 28px;
    font-weight: 400;
    margin:0;
    padding-right:5px;
    text-overflow:ellipsis;
    white-space:nowrap;
}
#list .nogoods{
  width:100%;
  text-align:center;
  background-color:#fff;
  height:50px;
}
#list .nogoods p{
  margin:0;
  padding:0;
  height:50px;
  line-height: 50px;
  font-size:16px;
}
/* 图片列表样式 */
#list .media_table{
  width:100%;
  margin-top:4px;
}
#list .media_item{
  width:100%;
  height:124px;
  background-color:#fff;
  position:relative;
  text-align:left;
  border-bottom:1px solid #E5E5E5;
}
#list .item_img{
  height:100%;
  position:absolute;
}
#list .item_text{
  position:absolute;
  top:0;
  left:124px;
  height:100%;
  color:#333;
  font-size:14px;
}
#list p.item_price{
  font-weight:bold;
  color:#dd2727;
  font-size:16px;
  position:absolute;
  bottom:0;
}
#list .item_sales{
  color:#999;
  font-size:12px;
}
#list .mui-bar-tab .mui-tab-item.mui-active{
  color:#929292;
}
/* 头部三点隐藏框 */

</style>
