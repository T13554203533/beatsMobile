set name utf8;
drop database if exists beatsMobile;
create database beatsMobile charset=utf8;
use beatsMobile;
create table m_list(
	id int(10) primary key auto_increment,
	pid int(10) not null unique,
	pic varchar(100),
	title varchar(200),
	price decimal(7,2),
	salesVolume int(10),
	time varchar(10)	
);
insert into m_list values (null,1,'http://127.0.0.1:3001/list_img/p1.jpg','��6����Ϣ��Beats Pro ¼��ʦרҵ��ͷ��ʽ��������',2782,5,'2019-1');
insert into m_list values (null,2,'http://127.0.0.1:3001/list_img/p2.jpg','��������Ϣ��Beats BeatsX����ʽ��������B�������ʽX��������-',799,6875,'2019-6');
insert into m_list values (null,3,'http://127.0.0.1:3001/list_img/p3.jpg','Beats urBeats3 ����ں� �ص����������ʽ�߿ض���10�����ر��',486,964,'2019-7');
insert into m_list values (null,4,'http://127.0.0.1:3001/list_img/p4.jpg','Beats urBeats 3 Lightning�ص�������b�������ʽ����',486,845,'2019-6');
insert into m_list values (null,5,'http://127.0.0.1:3001/list_img/p5.jpg','Beats urBeats 3�ص�������ʽb�������ʽͨ���߿ض���',799,542,'2019-2');
insert into m_list values (null,6,'http://127.0.0.1:3001/list_img/p7.jpg','��12����Ϣ��Beats Studio 3 Wireless���߽����������ͷ��ʽ',799,542,'2019-3');
insert into m_list values (null,7,'http://127.0.0.1:3001/list_img/p6.jpg','��������Ϣ��Beats BeatsX ���ʽ��������ʽ��������B��������',2209,696,'2019-4');
insert into m_list values (null,8,'http://127.0.0.1:3001/list_img/p8.jpg','��������Ϣ��Beats Solo3 Wireless �ر�� ����90�����������',2209,696,'2019-2');
insert into m_list values (null,9,'http://127.0.0.1:3001/list_img/p9.jpg','Beats Powerbeats3 Wireless ���߶��������˶����ʽ����',2209,617,'2019-9');
insert into m_list values (null,10,'http://127.0.0.1:3001/list_img/p10.jpg','Beats EP ͷ��ʽ���������ص�������ͨ��b����',799,131,'2018-5');
insert into m_list values (null,11,'http://127.0.0.1:3001/list_img/p11.jpg','Beats Powerbeats3 Wireless ����ں� ���ʽ���� 10�����ر��',1437,210,'2018-11');
insert into m_list values (null,12,'http://127.0.0.1:3001/list_img/p12.jpg','��6����Ϣ��Beats pill+ ���������������� ���û����˶��ص�����',761,228,'2018-10');
insert into m_list values (null,13,'http://127.0.0.1:3001/list_img/p13.jpg','Beats Studio 3 Wireless ����ں� ���߽������ 10�����ر��',1533,282,'2018-9');
insert into m_list values (null,14,'http://127.0.0.1:3001/list_img/p14.jpg','Beats Solo3 Wireless ͷ��ʽ���� ����ں� ���� 10�����ر��',1437,239,'2018-12');
insert into m_list values (null,15,'http://127.0.0.1:3001/list_img/p15.jpg','Beats Solo3 Wireless ͷ��ʽ����-�����ر�� - ������',2789,90,'2018-7');
insert into m_list values (null,16,'http://127.0.0.1:3001/list_img/p16.jpg','Beats Studio 3 Wireless�����������ͷ��ʽ������������',2209,243,'2018-3');
insert into m_list values (null,17,'http://127.0.0.1:3001/list_img/p17.jpg','��������Ϣ��Beats Solo3 Wireless Ultra Violetͷ��ʽ����',2209,42,'2018-5');
insert into m_list values (null,18,'http://127.0.0.1:3001/list_img/p18.jpg','Beats Studio3 Wireless ���߽����������ͷ��ʽ��������',2789,23,'2018-4');
insert into m_list values (null,19,'http://127.0.0.1:3001/list_img/p19.jpg','��12����Ϣ��Beats Solo3 Wireless ͷ��ʽ���߶���',486,54,'2018-3');
insert into m_list values (null,20,'http://127.0.0.1:3001/list_img/p20.jpg','Beats BeatsX����ں� ���ʽ��������ʽ���������� 10�����ر��',2209,5,'2018-2');
insert into m_list values (null,21,'http://127.0.0.1:3001/list_img/p21.jpg','��6����Ϣ��Beats Pro ¼��ʦרҵ��ͷ��ʽ��������',1437,2,'2018-8');
insert into m_list values (null,22,'http://127.0.0.1:3001/list_img/p22.jpg','��6����Ϣ��Beats pill+ ���������������� ���û����˶��ص�����',761,12,'2018-4');
insert into m_list values (null,23,'http://127.0.0.1:3001/list_img/p23.jpg','Beats EP ͷ��ʽ���������ص�������ͨ��b����',1533,10,'2018-5');
insert into m_list values (null,24,'http://127.0.0.1:3001/list_img/p24.jpg','Beats Solo3 Wireless ͷ��ʽ���� ����ں� ���� 10�����ر��',2789,3,'2018-7');
insert into m_list values (null,25,'http://127.0.0.1:3001/list_img/p25.jpg','Beats Powerbeats3 Wireless ���߶��������˶����ʽ����',1437,10,'2018-9');

create table m_user(
	id int(10) primary key auto_increment,
	uname varchar(20) unique,
	pwd varchar(64),
	phone varchar(20) unique

);
insert into m_user values (null,'mingming',md5(123456),'13455556666');

create table m_dt_img(
	id int(10) primary key auto_increment,
	pid int(10),
	pic varchar(200)
);
insert into m_dt_img values(null,1,'http://127.0.0.1:3001/detail_img/t1.jpg');
insert into m_dt_img values(null,1,'http://127.0.0.1:3001/detail_img/t2.jpg');
insert into m_dt_img values(null,1,'http://127.0.0.1:3001/detail_img/t3.jpg');
insert into m_dt_img values(null,1,'http://127.0.0.1:3001/detail_img/t4.jpg');
insert into m_dt_img values(null,1,'http://127.0.0.1:3001/detail_img/t5.jpg');
insert into m_dt_img values(null,2,'http://127.0.0.1:3001/detail_img/a1.jpg');
insert into m_dt_img values(null,2,'http://127.0.0.1:3001/detail_img/a2.jpg');
insert into m_dt_img values(null,2,'http://127.0.0.1:3001/detail_img/a3.jpg');
insert into m_dt_img values(null,2,'http://127.0.0.1:3001/detail_img/a4.jpg');
insert into m_dt_img values(null,2,'http://127.0.0.1:3001/detail_img/a5.jpg');
insert into m_dt_img values(null,3,'http://127.0.0.1:3001/detail_img/tc1.jpg');
insert into m_dt_img values(null,3,'http://127.0.0.1:3001/detail_img/tc2.jpg');
insert into m_dt_img values(null,3,'http://127.0.0.1:3001/detail_img/tc3.jpg');
insert into m_dt_img values(null,3,'http://127.0.0.1:3001/detail_img/tc4.jpg');
insert into m_dt_img values(null,3,'http://127.0.0.1:3001/detail_img/tc5.jpg');
insert into m_dt_img values(null,4,'http://127.0.0.1:3001/detail_img/td1.jpg');
insert into m_dt_img values(null,4,'http://127.0.0.1:3001/detail_img/td2.jpg');
insert into m_dt_img values(null,4,'http://127.0.0.1:3001/detail_img/td3.jpg');
insert into m_dt_img values(null,4,'http://127.0.0.1:3001/detail_img/td4.jpg');
insert into m_dt_img values(null,4,'http://127.0.0.1:3001/detail_img/td5.jpg');
insert into m_dt_img values(null,5,'http://127.0.0.1:3001/detail_img/te1.jpg');
insert into m_dt_img values(null,5,'http://127.0.0.1:3001/detail_img/te2.jpg');
insert into m_dt_img values(null,5,'http://127.0.0.1:3001/detail_img/te3.jpg');
insert into m_dt_img values(null,5,'http://127.0.0.1:3001/detail_img/te4.jpg');
insert into m_dt_img values(null,6,'http://127.0.0.1:3001/detail_img/tf1.jpg');
insert into m_dt_img values(null,6,'http://127.0.0.1:3001/detail_img/tf2.jpg');
insert into m_dt_img values(null,6,'http://127.0.0.1:3001/detail_img/tf3.jpg');
insert into m_dt_img values(null,6,'http://127.0.0.1:3001/detail_img/tf4.jpg');
insert into m_dt_img values(null,6,'http://127.0.0.1:3001/detail_img/tf5.jpg');

create table m_dd_img(
	id int(10) primary key auto_increment,
	pid int(10),
	pic varchar(200)
);
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c1.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c2.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c3.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c4.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c5.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c6.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c7.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c8.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c9.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c10.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c11.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c12.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c13.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c14.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c15.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c16.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c17.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c18.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c19.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c20.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c21.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c22.jpg');
insert into m_dd_img values(null,1,'http://127.0.0.1:3001/detail_img/c23.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b1.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b2.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b3.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b4.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b5.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b6.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b7.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b8.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b9.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b10.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b11.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b12.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b13.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b14.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b15.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b16.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b17.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b18.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b19.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b20.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b21.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b22.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b23.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b24.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b25.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b26.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b27.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b28.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b29.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b30.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b31.jpg');
insert into m_dd_img values(null,2,'http://127.0.0.1:3001/detail_img/b32.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc1.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc2.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc3.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc4.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc5.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc6.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc7.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc8.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc9.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc10.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc11.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc12.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc13.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc14.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc15.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc16.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc17.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc18.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc19.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc20.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc21.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc22.jpg');
insert into m_dd_img values(null,3,'http://127.0.0.1:3001/detail_img/dc23.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd1.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd2.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd3.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd4.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd5.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd6.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd7.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd8.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd9.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd10.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd11.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd12.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd13.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd14.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd15.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd16.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd17.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd18.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd19.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd20.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd21.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd22.jpg');
insert into m_dd_img values(null,4,'http://127.0.0.1:3001/detail_img/dd23.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de1.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de2.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de3.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de4.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de5.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de6.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de7.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de8.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de9.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de10.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de11.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de12.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de13.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de14.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de15.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de16.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de17.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de18.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de19.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de20.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de21.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de22.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de23.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de24.jpg');
insert into m_dd_img values(null,5,'http://127.0.0.1:3001/detail_img/de25.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df1.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df2.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df3.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df4.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df5.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df6.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df7.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df8.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df9.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df10.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df11.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df12.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df13.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df14.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df15.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df16.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df17.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df18.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df19.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df20.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df21.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df22.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df23.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df24.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df25.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df26.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df27.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df28.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df29.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df30.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df31.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df32.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df33.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df34.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df35.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df36.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df37.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df38.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df39.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df40.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df41.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df42.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df43.jpg');
insert into m_dd_img values(null,6,'http://127.0.0.1:3001/detail_img/df44.jpg');

