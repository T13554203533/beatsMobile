import Vue from 'vue'
import Router from 'vue-router'
import HelloContainer from "./components/HelloWorld.vue"
import Login from './components/tabbar/Login.vue'
import Register from './components/tabbar/Register'
import Home from './components/tabbar/Home'
import List from './components/tabbar/List'
import Introduce from './components/tabbar/Introduce'
import Cart from './components/tabbar/Cart'
import New from './components/tabbar/New'
import Seek from './components/tabbar/Seek'
import Interact from './components/tabbar/Interact'
import Chat from './components/tabbar/Chat'
import Detail from './components/tabbar/Detail'
Vue.use(Router)
export default new Router({
  routes: [
    {path:'/Detail',component:Detail},
    {path:'/Chat',component:Chat},
    {path:'/Interact',component:Interact},
    {path:'/Seek',component:Seek},
    {path:'/New',component:New},
    {path:'/Cart',component:Cart},
    {path:'/Introduce',component:Introduce},
    {path:'/List',component:List},
    {path:'/Login',component:Login},
    {path:'/Home',component:Home},
    {path:'/Register',component:Register}
  ]
})
